export { default } from './WalletPage';
